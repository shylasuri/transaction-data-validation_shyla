"""UI styling and configuration"""
import streamlit as st


def apply_styles():
    st.markdown(
        """
        <style>
        /* ---- Base Reset ---- */
        html, body, [class*="css"] {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }

        /* ---- App Background ---- */
        .stApp {
            background-color: #f8f9fb;
        }

        /* ---- Hide default Streamlit elements ---- */
        #MainMenu, footer, header { visibility: hidden; }
        .block-container {
            padding: 2rem 2.5rem 2rem 2rem;
            max-width: 1400px;
        }

        /* ---- Sidebar ---- */
        [data-testid="stSidebar"] {
            background-color: #0f172a;
            border-right: 1px solid #1e293b;
        }
        [data-testid="stSidebar"] > div:first-child {
            padding: 0;
        }

        /* ---- Sidebar Header ---- */
        .sidebar-header {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 24px 20px 20px;
        }
        .sidebar-logo {
            background: #2563eb;
            color: #fff;
            font-weight: 700;
            font-size: 14px;
            letter-spacing: 0.05em;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .sidebar-title {
            color: #f1f5f9;
            font-size: 12px;
            font-weight: 600;
            line-height: 1.4;
            letter-spacing: 0.01em;
        }

        /* ---- Sidebar Divider ---- */
        .sidebar-divider {
            height: 1px;
            background: #1e293b;
            margin: 8px 0;
        }

        /* ---- Nav Label ---- */
        .nav-label {
            color: #475569;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.12em;
            padding: 12px 20px 6px;
        }

        /* ---- Sidebar Buttons ---- */
        [data-testid="stSidebar"] .stButton button {
            background: transparent !important;
            color: #94a3b8 !important;
            border: none !important;
            border-radius: 6px !important;
            font-size: 13px !important;
            font-weight: 500 !important;
            text-align: left !important;
            padding: 9px 20px !important;
            margin: 1px 8px !important;
            width: calc(100% - 16px) !important;
            transition: all 0.15s ease !important;
            box-shadow: none !important;
        }
        [data-testid="stSidebar"] .stButton button:hover {
            background: #1e293b !important;
            color: #e2e8f0 !important;
        }
        [data-testid="stSidebar"] .stButton button[kind="primary"] {
            background: #1e40af !important;
            color: #dbeafe !important;
            font-weight: 600 !important;
        }

        /* ---- Info Card (Sidebar) ---- */
        .info-card {
            background: #1e293b;
            border-radius: 8px;
            padding: 12px 14px;
            margin: 8px 16px;
            font-size: 12px;
        }
        .info-card.muted {
            color: #64748b;
            line-height: 1.5;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 3px 0;
        }
        .info-key { color: #64748b; }
        .info-val { color: #e2e8f0; font-weight: 500; }
        .truncate {
            max-width: 100px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        /* ---- Score Card ---- */
        .score-card {
            background: #1e293b;
            border-radius: 8px;
            padding: 12px 14px;
            margin: 8px 16px;
            text-align: center;
        }
        .score-label { color: #64748b; font-size: 11px; letter-spacing: 0.06em; text-transform: uppercase; margin-bottom: 4px; }
        .score-value { font-size: 28px; font-weight: 700; }

        /* ---- Page Header ---- */
        .page-header {
            margin-bottom: 28px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }
        .page-title {
            font-size: 22px;
            font-weight: 700;
            color: #0f172a;
            margin: 0 0 4px;
            letter-spacing: -0.02em;
        }
        .page-subtitle {
            font-size: 14px;
            color: #64748b;
            margin: 0;
        }

        /* ---- Metric Cards ---- */
        .metric-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .metric-card {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 20px;
        }
        .metric-label {
            font-size: 12px;
            color: #64748b;
            font-weight: 500;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .metric-value {
            font-size: 28px;
            font-weight: 700;
            color: #0f172a;
            line-height: 1;
        }
        .metric-sub {
            font-size: 12px;
            color: #94a3b8;
            margin-top: 4px;
        }
        .metric-card.green { border-left: 3px solid #16a34a; }
        .metric-card.red   { border-left: 3px solid #dc2626; }
        .metric-card.amber { border-left: 3px solid #d97706; }
        .metric-card.blue  { border-left: 3px solid #2563eb; }

        /* ---- Section Card ---- */
        .section-card {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 24px;
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 15px;
            font-weight: 600;
            color: #0f172a;
            margin: 0 0 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid #f1f5f9;
        }

        /* ---- Status Badges ---- */
        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 0.04em;
        }
        .badge-pass { background: #dcfce7; color: #15803d; }
        .badge-fail { background: #fee2e2; color: #dc2626; }
        .badge-warn { background: #fef3c7; color: #b45309; }
        .badge-info { background: #dbeafe; color: #1d4ed8; }

        /* ---- Alert Boxes ---- */
        .alert-box {
            border-radius: 8px;
            padding: 14px 18px;
            margin-bottom: 16px;
            font-size: 13px;
            line-height: 1.5;
        }
        .alert-success { background: #f0fdf4; border: 1px solid #86efac; color: #14532d; }
        .alert-error   { background: #fef2f2; border: 1px solid #fca5a5; color: #7f1d1d; }
        .alert-warning { background: #fffbeb; border: 1px solid #fde68a; color: #78350f; }
        .alert-info    { background: #eff6ff; border: 1px solid #93c5fd; color: #1e3a8a; }

        /* ---- Table Tweaks ---- */
        .stDataFrame { border-radius: 8px; overflow: hidden; }
        .stDataFrame thead th {
            background: #f8f9fb !important;
            font-size: 12px !important;
            font-weight: 600 !important;
            color: #374151 !important;
        }

        /* ---- Expander ---- */
        .streamlit-expanderHeader {
            font-size: 13px !important;
            font-weight: 600 !important;
            color: #374151 !important;
            background: #f8f9fb !important;
            border-radius: 6px !important;
        }

        /* ---- Progress Bar ---- */
        .quality-bar-wrap {
            background: #f1f5f9;
            border-radius: 99px;
            height: 10px;
            overflow: hidden;
            margin-top: 6px;
        }
        .quality-bar-fill {
            height: 100%;
            border-radius: 99px;
            transition: width 0.4s ease;
        }

        /* ---- Insight Item ---- */
        .insight-item {
            display: flex;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
            align-items: flex-start;
        }
        .insight-item:last-child { border-bottom: none; }
        .insight-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-top: 5px;
            flex-shrink: 0;
        }
        .insight-text { font-size: 13px; color: #374151; line-height: 1.5; }
        .insight-title { font-weight: 600; color: #0f172a; }

        /* ---- Main buttons ---- */
        .stButton button[kind="primary"] {
            background: #2563eb !important;
            border-color: #2563eb !important;
            font-weight: 600 !important;
            border-radius: 7px !important;
        }
        .stButton button[kind="secondary"] {
            border-radius: 7px !important;
        }

        /* ---- Tabs ---- */
        .stTabs [data-baseweb="tab-list"] {
            background: #f1f5f9;
            border-radius: 8px;
            padding: 4px;
            gap: 2px;
            border: none;
        }
        .stTabs [data-baseweb="tab"] {
            background: transparent;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            color: #64748b;
            padding: 6px 16px;
        }
        .stTabs [aria-selected="true"] {
            background: #fff !important;
            color: #0f172a !important;
            font-weight: 600 !important;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
